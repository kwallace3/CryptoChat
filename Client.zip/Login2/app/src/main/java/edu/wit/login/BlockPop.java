package edu.wit.login;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class BlockPop extends Activity {
    Button enter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blockpop);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.85), (int)(height*.5));

        if(getIntent().getExtras() != null)
        {
            Bundle bundle = getIntent().getExtras();
            if(bundle.getString("name") != "") {
                TextView name = findViewById(R.id.blocked);
                name.setText("You blocked " + bundle.getString("name"));
            }
        }

        enter = findViewById(R.id.enter);
        enter.setMovementMethod(LinkMovementMethod.getInstance());
        enter.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(BlockPop.this, MainPage.class);
                startActivity(intent);
            }
        });
    }
}
