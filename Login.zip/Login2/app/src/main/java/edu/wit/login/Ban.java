package edu.wit.login;

public class Ban {
}
