package edu.wit.login;

import android.annotation.SuppressLint;
import androidx.appcompat.app.AppCompatActivity;
import java.net.*;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


// reference:https://www.tutorialspoint.com/sending-and-receiving-data-with-sockets-in-android
@SuppressLint("SetTextI18n")
public class NetworkOPS extends AppCompatActivity {

    public Socket execute() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.submit(() -> {
            try {
                InetAddress address = InetAddress.getByName("cryptochatwit.duckdns.org");
                Socket socket = new Socket(address, 4995);
                return socket;
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


            return null;
        });
        return null;
    }
    public String retrieve(String user, String pass) throws Exception{
        Socket connect = execute();
        InputStream is = connect.getInputStream();
        InputStreamReader message = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(message);
        System.out.println(br);
        // Read greeting from the server.
        String response = br.readLine();

        if (response.contains(user) && response.contains(pass) ){
            connect.close();
            return "login%7success%##username";
        }
        else
            connect.close();
        return br.toString();

    }
    public void write(String username, String Password, String Email) throws Exception{
        Socket connect = execute();
        // Get a reference to the socket's output stream.
        OutputStream os = connect.getOutputStream();
        //Send data to server
        String User = findViewById(R.id.newname).toString();
        String pass = findViewById(R.id.txtPassword).toString();
        String email = findViewById(R.id.txtEmail).toString();

        os.write(User.getBytes());
        os.write(pass.getBytes());
        os.write(email.getBytes());

        connect.close();
    }


}