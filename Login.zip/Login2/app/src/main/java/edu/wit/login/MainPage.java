package edu.wit.login;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.TextView;


public class MainPage extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainpage);
        TextView logout = (TextView)findViewById(R.id.LObutton);
        logout.setMovementMethod(LinkMovementMethod.getInstance());
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainPage.this, MainActivity.class);
                startActivity(intent);
            }
        });
        TextView dm = findViewById(R.id.dm);
        dm.setMovementMethod(LinkMovementMethod.getInstance());
        dm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainPage.this,Directmsg.class);
                startActivity(intent);
            }
        });
        TextView ban = findViewById(R.id.ban);
        ban.setMovementMethod(LinkMovementMethod.getInstance());
        ban.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainPage.this,Ban.class);
                startActivity(intent);
            }
        });
    }
    }

