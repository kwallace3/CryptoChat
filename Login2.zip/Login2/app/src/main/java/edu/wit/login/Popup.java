package edu.wit.login;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

public class Popup extends Activity {
    Button enter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.popup);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.85), (int)(height*.5));

        enter = findViewById(R.id.enter);
        enter.setMovementMethod(LinkMovementMethod.getInstance());
        enter.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText username = findViewById(R.id.Username);
                String name = username.getText().toString();
                Intent intent = new Intent(Popup.this, Directmsg.class);
                intent.putExtra("name",name);
                startActivity(intent);
            }
        });
    }
}
