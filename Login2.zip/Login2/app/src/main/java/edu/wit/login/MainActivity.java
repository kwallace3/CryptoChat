package edu.wit.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

//reference: https://www.tutorialspoint.com/android/android_login_screen.htm
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button register = findViewById(R.id.CAbutton);


        register.setMovementMethod(LinkMovementMethod.getInstance());
        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Register.class);
                startActivity(intent);
            }
        });

        Button login = findViewById(R.id.Lbutton);
        login.setMovementMethod(LinkMovementMethod.getInstance());
        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText username = findViewById(R.id.Username);
                EditText password = findViewById(R.id.Password);
                System.out.println("login%##"+username.getText().toString()+
                        "%##"+password.getText().toString());
                Intent intent = new Intent(MainActivity.this, MainPage.class);
                intent.putExtra("name", username.getText().toString());
                startActivity(intent);
            }
        });
    }

}