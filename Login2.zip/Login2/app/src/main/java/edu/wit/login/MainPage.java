package edu.wit.login;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainPage extends Activity {
    Button block;
    Button sendMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainpage);

        if(getIntent().getExtras() != null)
        {
            Bundle bundle = getIntent().getExtras();
            TextView name = findViewById(R.id.loginName);
            name.setText("Hello "+ bundle.getString("name")+"!");
        }

        block = findViewById(R.id.btnBlock);
        block.setMovementMethod(LinkMovementMethod.getInstance());
        block.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainPage.this, Ban.class);
                startActivity(intent);
            }
        });

        sendMsg = findViewById(R.id.sendMsg);
        sendMsg.setMovementMethod(LinkMovementMethod.getInstance());
        sendMsg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainPage.this, Popup.class));
            }
        });
    }
}
