package edu.wit.login;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//reference: https://www.tutlane.com/tutorial/android/android-login-and-registration-screen-design
public class Register extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        TextView register = (TextView) findViewById(R.id.lnkLogin);
        Button createButton = findViewById(R.id.btnCA);

        register.setMovementMethod(LinkMovementMethod.getInstance());
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Register.this, MainActivity.class);
                startActivity(intent1);
            }
        });

        createButton.setMovementMethod(LinkMovementMethod.getInstance());
        createButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText username = findViewById(R.id.newname);
                EditText email = findViewById(R.id.txtEmail);
                EditText password = findViewById(R.id.txtPassword);
                EditText passCheck = findViewById(R.id.txtRePwd);

                if(passCheck.getText().toString().equals(password.getText().toString()))
                {
                    System.out.println("createaccount%##"+ username.getText().toString() + "%##" +
                            email.getText().toString() + "%##" + password.getText().toString());
                    Intent intent2 = new Intent(Register.this, MainPage.class);
                    intent2.putExtra("name", username.getText().toString());
                    startActivity(intent2);
                }
                else
                {
                    System.out.println("ERROR! Passwords did not match. Please try again.");
                    Intent intent3 = new Intent(Register.this, Register.class);
                    startActivity(intent3);
                }
            }
        });
    }
}