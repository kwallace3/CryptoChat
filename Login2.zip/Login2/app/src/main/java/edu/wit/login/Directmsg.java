package edu.wit.login;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ButtonBarLayout;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

@SuppressLint("Registered")
public class Directmsg extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.directmsg);
        TextView name = findViewById(R.id.Name);
        Button done = findViewById(R.id.done);
        Button send = findViewById(R.id.btnSend);
        Bundle bundle = getIntent().getExtras();
        String receivingUser = "";

        name.setText(bundle.getString("name"));

        done.setMovementMethod(LinkMovementMethod.getInstance());
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Directmsg.this, MainPage.class);
                startActivity(intent);
            }
        });

        send.setMovementMethod(LinkMovementMethod.getInstance());
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText sendMessage = findViewById(R.id.etMessage);
                TextView messageBox = findViewById(R.id.tvMessages);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
                String timestamp = sdf.format(new Date());

                System.out.println("senddirectmessage%"+ receivingUser + "%"+ timestamp +
                        "%"+ sendMessage.getText().toString());

                String newText = messageBox.getText().toString() + "\n"+ sendMessage.getText().toString();

                messageBox.setText(newText);
                sendMessage.setText("");
            }
        });
    }
}
